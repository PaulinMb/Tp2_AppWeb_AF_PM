import React from 'react';
import './css/styles.css';

function Accueil() {
    return (
        <div className="accueil-container">
            <h1>Bienvenue sur la page d'accueil de votre calendrier.</h1>
        </div>
    );
}

export default Accueil;
